//
//  ModelContainer.swift
//  HuliPizzaPersistent
//
//  Created by Steven Lipton on 1/21/24.
//

import Foundation
import SwiftData

typealias OrderTicket = HPSchemaV01_00_00.OrderTicket
typealias OrderItem = HPSchemaV01_00_00.OrderItem
typealias NameModel = HPSchemaV01_00_00.NameModel
typealias RatingModel = HPSchemaV01_00_00.RatingModel

var modelContainer:ModelContainer{
//    let schema = Schema([OrderTicket.self,NameModel.self,RatingModel.self,OrderItem.self])
    let schema = Schema(versionedSchema: HPSchemaV01_00_00.self)
    let modelConfiguration = ModelConfiguration( )
    let modelContainer = try! ModelContainer(for: schema, configurations: modelConfiguration)
    return modelContainer
}

var autoSaveModelContainer:ModelContainer{
    let schema = Schema([OrderTicket.self,NameModel.self,RatingModel.self,OrderItem.self])
    let modelConfiguration = ModelConfiguration(isStoredInMemoryOnly:true )
    let modelContainer = try! ModelContainer(for: schema, configurations: modelConfiguration)
    let modelContext = ModelContext(modelContainer)
    modelContext.autosaveEnabled = true
    modelContext.insert(NameModel(name: "Steve", partySize: 2))
    modelContext.insert(NameModel(name: "Nova Aloha", partySize: 6))
    return modelContainer
}

